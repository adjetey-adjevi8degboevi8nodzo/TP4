package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.tp4.databinding.ActivityInfosBinding;
import com.example.tp4.databinding.ActivityMainBinding;

public class InfosActivity extends AppCompatActivity {
    private ActivityInfosBinding di;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        di = ActivityInfosBinding.inflate(getLayoutInflater());
        setContentView(di.getRoot());
        setTitle(getLocalClassName());

        di.bouton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int compteur = 6;
                di.texte.setText("compteur ="+compteur);

                finish();

            }
        });
    }
}