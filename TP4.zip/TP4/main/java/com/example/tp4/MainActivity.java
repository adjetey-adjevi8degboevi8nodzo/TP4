package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.tp4.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
private static final String TAG="TP4";
private ActivityMainBinding ui;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // initialisation interne de l'activite
        super.onCreate(savedInstanceState);
        // mise en place du layout par un view binging
        ui = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        //titre de l'activite
        setTitle(getLocalClassName());
        Log.i(TAG,"dans"+getLocalClassName()+".onCreate");
       TextView textView = findViewById(R.id.texte);


        // ecouteur pour le bouton 2, lambda
       // ui.bouton2.setOnClickListener(btn -> {
         //   compteur += 2;
           // ui.texte.setText("compteur ="+compteur);
        //});

        // ecouteur pour le bouton 2, classe privee anonyme
        ui.bouton2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
              // compteur +=5;
               TP4Application app = (TP4Application) getApplicationContext();
               int compteur = app.getCompteur();
               ui.texte.setText("compteur ="+compteur);
           }
        });

        ui.bouton3.setOnClickListener(this::onBouton3Click);
        ui.bouton4.setOnClickListener(this);

        ui.bouton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //compteur +=5;
                TP4Application app = (TP4Application) getApplicationContext();
                int compteur = app.getCompteur();
                ui.texte.setText("compteur ="+compteur);

                Intent intent =  new Intent(MainActivity.this, InfosActivity.class);

                startActivity(intent);
            }

        });

        ui.bouton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //compteur +=6;
                TP4Application app = (TP4Application) getApplicationContext();
                int compteur = app.getCompteur();
                ui.texte.setText("compteur ="+compteur);

                finish();

                Intent intent =  new Intent(MainActivity.this, InfosActivity.class);

                startActivity(intent);
            }
        });


        Intent intent= getIntent();
        String information= intent.getStringExtra("username");
        textView.setText("Bonjour "+information);
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG,"dans "+getLocalClassName()+".onDestroy");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"dans "+getLocalClassName()+".onPause");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"dans "+getLocalClassName()+".onResume");
    }

    private int compteur = 0;

    public void onBouton1Click(View view){
        //compteur += 1 ;
        TP4Application app = (TP4Application) getApplicationContext();
        int compteur = app.getCompteur();
        ui.texte.setText("compteur ="+compteur);
    }
    private void onBouton3Click(View view){
        //compteur *= 2;
        TP4Application app = (TP4Application) getApplicationContext();
        int compteur = app.getCompteur();
        ui.texte.setText("compteur = "+compteur);
    }

    @Override
    public void onClick(View view){
        //compteur *= 5;
        TP4Application app = (TP4Application) getApplicationContext();
        int compteur = app.getCompteur();
        ui.texte.setText("compteur = "+compteur);
    }
}
